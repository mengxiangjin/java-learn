package custom.bean;

public class TSBean {
    private int serialNumber;
    private String downloadURl;


    public int getSerialNumber() {
        return serialNumber;
    }

    public void setSerialNumber(int serialNumber) {
        this.serialNumber = serialNumber;
    }

    public String getDownloadURl() {
        return downloadURl;
    }

    public void setDownloadURl(String downloadURl) {
        this.downloadURl = downloadURl;
    }
}
