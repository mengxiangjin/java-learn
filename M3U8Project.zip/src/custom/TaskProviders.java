package custom;

import custom.bean.TSBean;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import static custom.M3U8Downloader.DOWNLOAD_PATH;

public class TaskProviders {


    public static List<Task> getTaskList() {
        List<Task> result = new ArrayList<>();
        result.add(new Task(
                "https://1322323636.vod-qcloud.com/fd3c1c01vodcq1322323636/a3ef6b4f1397757901943576061/playlist_eof.m3u8?t=67b884bd&rlimit=2&us=53&sign=5f25ab4fff05e6134b7f2ce21da9381f",
                "泡芙s三主黄金",
                "调教"));
        result.add(new Task(
                "https://1322323636.vod-qcloud.com/fd3c1c01vodcq1322323636/8c53ddc81397757901447317332/playlist_eof.m3u8?t=67b884c1&rlimit=2&us=74&sign=051c922396fc25f0808dec0b19ef3853",
                "泡芙s三主黄金",
                "开发04大学生吃黄金"));
        result.add(new Task(
                "https://1322323636.vod-qcloud.com/fd3c1c01vodcq1322323636/afea9a391397757901288994218/playlist_eof.m3u8?t=67b884c6&rlimit=2&us=40&sign=fafe4df4a751ca6266f86fc2147ea9d4",
                "泡芙s三主黄金",
                "调04大二学生"));
        result.add(new Task(
                "https://1322323636.vod-qcloud.com/fd3c1c01vodcq1322323636/060d6e9d1397757905509882298/playlist_eof.m3u8?t=67b884c9&rlimit=2&us=11&sign=27a214843f24f45455265967059a12bf",
                "泡芙s三主黄金",
                "双主回放更新去买"));
        result.add(new Task(
                "https://1322323636.vod-qcloud.com/fd3c1c01vodcq1322323636/97ea160b1397757905566124063/playlist_eof.m3u8?t=67b884cd&rlimit=2&us=70&sign=6aa47c8a8026ac6d1d14ac5340524643",
                "泡芙s三主黄金",
                "呕吐物更新"));
        result.add(new Task(
                "https://1322323636.vod-qcloud.com/fd3c1c01vodcq1322323636/97cd77701397757905328116719/playlist_eof.m3u8?t=67b884cf&rlimit=2&us=68&sign=0079e325fb316c2658155542f11ef639",
                "泡芙s三主黄金",
                "三主黄金更新"));
        result.add(new Task(
                "https://1322323636.vod-qcloud.com/fd3c1c01vodcq1322323636/678b83b71397757905429756930/playlist_eof.m3u8?t=67b884d3&rlimit=2&us=68&sign=8c956b2662b8494ba15d3e0d5f267d6f",
                "泡芙s三主黄金",
                "三主脚奴黄金视频更新"));
        result.add(new Task(
                "https://1322323636.vod-qcloud.com/fd3c1c01vodcq1322323636/1e3b0cb11397757904119921782/playlist_eof.m3u8?t=67b884d8&rlimit=2&us=24&sign=d79179064bcdbca9f0571138372be153",
                "泡芙s三主黄金",
                "1"));
        result.add(new Task(
                "https://1322323636.vod-qcloud.com/fd3c1c01vodcq1322323636/df0f258d1397757903764153317/playlist_eof.m3u8?t=67b884da&rlimit=2&us=88&sign=fb5b942cea693df663a2f80ecac95042",
                "泡芙s三主黄金",
                "聊天"));
        result.add(new Task(
                "https://1322323636.vod-qcloud.com/fd3c1c01vodcq1322323636/7093d74c1397757903521924841/playlist_eof.m3u8?t=67b884dd&rlimit=2&us=54&sign=059a9af2a983c533c0c385d5c97807c8",
                "泡芙s三主黄金",
                "去买回放"));
        result.add(new Task(
                "https://1322323636.vod-qcloud.com/fd3c1c01vodcq1322323636/bb973b7d1397757902203032246/playlist_eof.m3u8?t=67b884e1&rlimit=2&us=95&sign=cf59d4e00618fe0422cfdb197afcb4ac",
                "泡芙s三主黄金",
                "黄金回放更新"));
        result.add(new Task(
                "https://1322323636.vod-qcloud.com/fd3c1c01vodcq1322323636/5a3f4c141397757901175395727/playlist_eof.m3u8?t=67b884e3&rlimit=2&us=81&sign=3a62ee98bd751754501298992f12fc16",
                "泡芙s三主黄金",
                "收合肥直播奴"));
        result.add(new Task(
                "https://1322323636.vod-qcloud.com/fd3c1c01vodcq1322323636/ed012d221397757900832302137/playlist_eof.m3u8?t=67b884e7&rlimit=2&us=50&sign=a668a4d76e36d9f0909ab5bdbc0ebb07",
                "泡芙s三主黄金",
                "爬进来"));
        result.add(new Task(
                "https://1322323636.vod-qcloud.com/fd3c1c01vodcq1322323636/2766481e1397757897376345338/playlist_eof.m3u8?t=67b884ea&rlimit=2&us=86&sign=d5ed302a269d826d3f5a3bd91f0b0d48",
                "泡芙s三主黄金",
                "呀第二天"));
        return result;
    }


    /**
     *
    private static final String M3U8_URL = "https://1322323636.vod-qcloud.com/fd3c1c01vodcq1322323636/c0a543881397757897687479029/playlist_eof.m3u8?t=6739b32f&rlimit=2&us=37&sign=f8913cfebad07b1d2b37159b6d52e491";
    private static final String fileName = "test.mp4";
    private static String MSU8_URL_PREFIX = "";
    private static final String FILE_PATH = DOWNLOAD_PATH + "tmp.m3u8";
    private static final String TMP_NAME = "tmp.txt";
    public static int tsFileTotalCounts = 0;
     */
    public static class Task {

        //地址
        private String m3u8Url;

        //父文件夹名称
        private String parentDirName;

        //生成mp4的名称 test 不带尾缀
        private String fileName;

        //地址前缀
        private String m3u8UrlPrefix;

        //xxx.m3u8文件路径 DOWNLOAD_PATH + "tmp.m3u8";
        private String m3u8FilePath;

        //ffmpeg合成所需的txt文件  tmp.txt
        private String tsList;

        //下载ts片段路径
        private String downloadTsPath;

        private int tsFileTotalCounts;

        private List<TSBean> tsBeanList;

        private ExecutorService executorService;


        public Task(String m3u8Url,String parentDirName,String fileName) {
            this.parentDirName = parentDirName;
            this.m3u8Url = m3u8Url;
            this.fileName = fileName;
            this.m3u8UrlPrefix = m3u8Url.substring(0,m3u8Url.indexOf("playlist_eof") - 1) + "/";
            this.downloadTsPath = DOWNLOAD_PATH + "\\" + parentDirName + "\\" + fileName + "\\";
            this.m3u8FilePath = downloadTsPath + fileName + ".m3u8";
            this.tsList = downloadTsPath + fileName + ".txt";
            tsBeanList = new ArrayList<>();
            executorService  = Executors.newFixedThreadPool(40);
        }

        public String getM3u8Url() {
            return m3u8Url;
        }

        public void setM3u8Url(String m3u8Url) {
            this.m3u8Url = m3u8Url;
        }

        public String getFileName() {
            return fileName;
        }

        public void setFileName(String fileName) {
            this.fileName = fileName;
        }

        public String getM3u8UrlPrefix() {
            return m3u8UrlPrefix;
        }

        public void setM3u8UrlPrefix(String m3u8UrlPrefix) {
            this.m3u8UrlPrefix = m3u8UrlPrefix;
        }

        public String getM3u8FilePath() {
            return m3u8FilePath;
        }

        public void setM3u8FilePath(String m3u8FilePath) {
            this.m3u8FilePath = m3u8FilePath;
        }

        public String getTsList() {
            return tsList;
        }

        public void setTsList(String tsList) {
            this.tsList = tsList;
        }

        public int getTsFileTotalCounts() {
            return tsFileTotalCounts;
        }

        public void setTsFileTotalCounts(int tsFileTotalCounts) {
            this.tsFileTotalCounts = tsFileTotalCounts;
        }

        public String getDownloadTsPath() {
            return downloadTsPath;
        }

        public void setDownloadTsPath(String downloadTsPath) {
            this.downloadTsPath = downloadTsPath;
        }

        public String getParentDirName() {
            return parentDirName;
        }

        public void setParentDirName(String parentDirName) {
            this.parentDirName = parentDirName;
        }

        public List<TSBean> getTsBeanList() {
            return tsBeanList;
        }

        public void setTsBeanList(List<TSBean> tsBeanList) {
            this.tsBeanList = tsBeanList;
        }

        public ExecutorService getExecutorService() {
            return executorService;
        }

        public void setExecutorService(ExecutorService executorService) {
            this.executorService = executorService;
        }

        @Override
        public String toString() {
            return "Task{" +
                    "m3u8Url='" + m3u8Url + '\'' +
                    ", parentDirName='" + parentDirName + '\'' +
                    ", fileName='" + fileName + '\'' +
                    ", m3u8UrlPrefix='" + m3u8UrlPrefix + '\'' +
                    ", m3u8FilePath='" + m3u8FilePath + '\'' +
                    ", tsList='" + tsList + '\'' +
                    ", downloadTsPath='" + downloadTsPath + '\'' +
                    ", tsFileTotalCounts=" + tsFileTotalCounts +
                    ", tsBeanList=" + tsBeanList +
                    ", executorService=" + executorService +
                    '}';
        }
    }
}
