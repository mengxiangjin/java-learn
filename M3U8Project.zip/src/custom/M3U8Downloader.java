package custom;

import custom.bean.TSBean;
import custom.utils.TsDownload;

import java.io.*;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.*;
import java.util.concurrent.*;

/**
 * @description: 下载 ok 资源网、最大资源网的  m3u8连接
 * @AuThor gitsilence
 * @version 1.0
 * @date 2020/12/11 14:59
 */
public class M3U8Downloader {

    public static final String DOWNLOAD_PATH = "E:\\work\\video\\";

    private static List<TaskProviders.Task> taskList;

    public volatile static int taskCounts = 0;

    public static void main(String[] args) {
        long startTime = System.currentTimeMillis();
        taskList = TaskProviders.getTaskList();
        taskCounts = taskList.size();
        try {
            // 创建父级文件夹
            createParentDirs();

            ExecutorService executorService = Executors.newFixedThreadPool(40);


            // 下载外层m3u8 url
            for (int i = 0; i < taskList.size(); i++) {
                TaskProviders.Task task = taskList.get(i);
                downloadFileFormTask(task);

                List<TSBean> tsBeanFromTask = getTsBeanFromTask(task);
                task.setTsFileTotalCounts(tsBeanFromTask.size());
                task.setTsBeanList(tsBeanFromTask);
                createMergeVideoTmpFromTask(task);

                for (int j = 0; j < task.getTsBeanList().size(); j++) {
                    TSBean tsBean = task.getTsBeanList().get(j);
                    executorService.execute(new TsDownload(tsBean.getSerialNumber(),tsBean.getDownloadURl(),task));
                };
            }

            // 关闭线程池，等待任务结束。
            executorService.shutdown();
            while (!executorService.isTerminated() && taskCounts > 0) {
                System.out.println("任务下载中");
                try {
                    TimeUnit.SECONDS.sleep(1);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            // 任务下载完毕后
            for (int i = 0; i < taskList.size(); i++) {
                TaskProviders.Task task = taskList.get(i);
                boolean isSuccess = mergeVideoFromTask(task);
                System.out.println("result end: " + isSuccess);
                if (isSuccess) {
                    // 移动目标mp4整合文件到上一级
                    moveAndDelDirFromTask(task);
                }

            }
            long second = (System.currentTimeMillis() - startTime) / 1000;
            long hour = second / 60 / 60;
            long minute = second / 60 % 60;
            long sec = second % 60 % 60;
            System.out.println("总耗时间: " + hour + "时" + minute + "分" + sec + "秒");
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    public static void moveAndDelDirFromTask(TaskProviders.Task task)throws IOException {
        File dstFile = new File(task.getDownloadTsPath() + task.getFileName() + ".mp4");
        if (!dstFile.exists()) return;
        File targetFile = new File(DOWNLOAD_PATH + "\\" + task.getParentDirName());
        Files.move(dstFile.toPath(),targetFile.toPath().resolve(dstFile.toPath().getFileName()), StandardCopyOption.REPLACE_EXISTING);
        File file = new File(DOWNLOAD_PATH + "\\" + task.getParentDirName() + "\\" + task.getFileName() + "\\");
        if (!file.exists() || file.isFile()) return;
        Files.walkFileTree(Paths.get(file.getPath()), new FileVisitor<Path>() {
            @Override
            public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs) throws IOException {
                return FileVisitResult.CONTINUE;
            }

            @Override
            public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
                Files.delete(file);
                return FileVisitResult.CONTINUE;
            }

            @Override
            public FileVisitResult visitFileFailed(Path file, IOException exc) throws IOException {
                return FileVisitResult.CONTINUE;
            }

            @Override
            public FileVisitResult postVisitDirectory(Path dir, IOException exc) throws IOException {
                Files.delete(dir);
                return FileVisitResult.CONTINUE;
            }
        });
        file.delete();
    }

    public static void downloadFileFormTask(TaskProviders.Task task) throws IOException {
        String m3u8Url = task.getM3u8Url();
        System.out.println("下载地址：" + m3u8Url);
        URL url = new URL(m3u8Url);
        URLConnection conn = url.openConnection();


        File f = new File(task.getM3u8FilePath());
        if (f.exists()) {
            f.delete();
        }

        RandomAccessFile file = new RandomAccessFile(task.getM3u8FilePath(), "rw");
        InputStream inputStream = conn.getInputStream();

        byte[] buffer = new byte[1024];
        int hasRead = 0;
        while ((hasRead = inputStream.read(buffer)) != -1) {
            file.write(buffer, 0, hasRead);
        }
        file.close();
        inputStream.close();
    }

    public static List<TSBean> getTsBeanFromTask(TaskProviders.Task task) {
        int serialNumber = 0;
        String path = task.getM3u8FilePath();
        List<TSBean> tsBeanList = new ArrayList<>();

        System.out.println("读取文件地址：" + path);
        StringBuilder builder = new StringBuilder();
        try {
            RandomAccessFile randomAccessFile = new RandomAccessFile(path, "r");
            String content = null;
            while ((content = randomAccessFile.readLine()) != null) {
                if (!content.startsWith("#")) {
                    serialNumber++;
                    TSBean tsBean = new TSBean();
                    tsBean.setSerialNumber(serialNumber);
                    tsBean.setDownloadURl(task.getM3u8UrlPrefix() + content);
                    tsBeanList.add(tsBean);
                    builder.append(content + "\n");
                }
            }
            randomAccessFile.close();
            return tsBeanList;
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return tsBeanList;
    }

    public static void createMergeVideoTmpFromTask (TaskProviders.Task task) {
        List<TSBean> tsBeanList = task.getTsBeanList();
        File file = new File(task.getTsList());
        if (file.exists()) {
            file.delete();
        }
        try {
            RandomAccessFile randomAccessFile = new RandomAccessFile(task.getTsList(), "rw");
            for (TSBean tsBean : tsBeanList) {
                randomAccessFile.write(("file '" + tsBean.getSerialNumber() + ".ts" + "'\n").getBytes());
            }
            randomAccessFile.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    /**
     * 执行cmd命令时，容易卡死，下面这种方式 正好解决办法
     * https://blog.csdn.net/myloveheqiaozhi/article/details/51451285
     * @param filename 合并之后，视频的名字
     */
    public static boolean mergeVideoFromTask (TaskProviders.Task task) {
        System.out.println("开始合并视频...." + task.getFileName());
        File file = new File(task.getTsList());
        String path = task.getDownloadTsPath().replaceAll("\\\\", "/");
        // 合并视频的命令
        try {
            Process process = Runtime.getRuntime().exec(String.format("ffmpeg.exe -f concat -safe 0 -i %s -c copy %s" +
                            ".mp4",
                    task.getTsList(), path + task.getFileName()));

            final InputStream is1 = process.getInputStream();
            new Thread(new Runnable(){
                @Override
                public void run() {
                    BufferedReader br = new BufferedReader(new InputStreamReader(is1));
                    try {
                        String outputLine = null;
                        while((outputLine=br.readLine())!= null) {
                            System.out.println(outputLine);
                        }

                    }catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }).start();
            InputStream is2 = process.getErrorStream();
            BufferedReader br2 = new BufferedReader(new InputStreamReader(is2));
            StringBuilder buf = new StringBuilder();
            String line = null;
            while((line = br2.readLine()) != null) {
                System.out.println(line);
                buf.append(line);
            };
            System.out.println("result:" + buf);
            while (br2.readLine() != null) {
                System.out.println(br2);
            }
            try {
                process.waitFor();
            }catch (InterruptedException e){
                e.printStackTrace();
                return false;
            }
            int i = process.exitValue();
            System.out.println( process.exitValue());

        } catch (IOException e) {
            e.printStackTrace();
            return false;
        } finally {
            file.delete();
        }
        return true;
    }




    public static void createParentDirs () {
        for (int i = 0; i < taskList.size(); i++) {
            TaskProviders.Task task = taskList.get(i);
            File itemFile = new File(DOWNLOAD_PATH + task.getParentDirName() + "\\" + task.getFileName());
            if (!itemFile.exists()) {
                itemFile.mkdirs();
            }
        }
    }

}


