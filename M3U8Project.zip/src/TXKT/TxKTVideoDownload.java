package TXKT;


import com.google.gson.*;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.util.zip.GZIPInputStream;

/*
* 腾讯课堂视频缓存
* */
public class TxKTVideoDownload {

    public static final String url_host = "https://ke.qq.com/user/index/index.html#/plan/cid=1647623&term_id=101747291";
    public static final String courseId = "1647623";
    public static final String termId = "101747291";


    public static void main(String[] args) throws IOException {
        getCourseList();

//        try {
//            // 创建URL对象
//            URL url = new URL("https://www.baidu.com");
//            // 打开连接
//            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
//            // 设置请求方法为GET
//            connection.setRequestMethod("GET");
//
//            // 连接
//            connection.connect();
//
//            // 获取响应码
//            int responseCode = connection.getResponseCode();
//            System.out.println("Response Code: " + responseCode);
//
//            // 判断响应码是否是HTTP_OK
//            if (responseCode == HttpURLConnection.HTTP_OK) {
//                // 获取响应内容
//                InputStream in = connection.getInputStream();
//                BufferedReader reader = new BufferedReader(new InputStreamReader(in));
//                StringBuffer buffer = new StringBuffer();
//                String line;
//                while ((line = reader.readLine()) != null) {
//                    buffer.append(line);
//                }
//                System.out.println("Response: " + buffer.toString());
//                // 关闭连接和流
//                reader.close();
//                connection.disconnect();
//            } else {
//                System.out.println("GET request not worked");
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
    }


    public static void getCourseList()throws IOException {
        String termsUrl = "https://ke.qq.com/cgi-bin/course/get_terms_detail?cid="+ courseId +"&term_id_list=%5B"+ termId +"%5D&bkn=&preload=1";
        URL url = new URL(termsUrl);
        HttpURLConnection conn = (HttpURLConnection)url.openConnection();
        conn.setRequestProperty("Host","ke.qq.com");
        conn.setRequestProperty("Sec-Ch-Ua","\"Not.A/Brand\";v=\"8\", \"Chromium\";v=\"114\", \"Microsoft Edge\";v=\"114\"");
        conn.setRequestProperty("Sec-Ch-Ua-Mobile","?0");
        conn.setRequestProperty("User-Agent","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36 Edg/114.0.1823.43");
        conn.setRequestProperty("Sec-Ch-Ua-Platform","Windows");
        conn.setRequestProperty("Accept","*/*");
        conn.setRequestProperty("Sec-Fetch-Site","same-origin");

        conn.setRequestProperty("Sec-Fetch-Mode","cors");

        conn.setRequestProperty("Sec-Fetch-Dest","empty");
        conn.setRequestProperty("Referer","https://ke.qq.com/webcourse/index.html");
//        conn.setRequestProperty("Accept-Encoding","gzip,deflate");
        conn.setRequestProperty("Accept-Language","zh-CN,zh;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6");
        conn.setRequestProperty("cookie","uid_uin=1289938984; uid_a2=864983fa3274767e6dbf4b3628ea36284a5311abfb8d23d6f51888af9aaa23dca4e03414dbcb5ec51b516cecaf0778ecf6d6d9503a95131096805eedec931059ed060dd029fcf7b0; uid_origin_uid_type=0; uid_origin_auth_type=1003;");
        conn.setRequestProperty("Content-Type", "application/json;charset=UTF-8");//一般在设置http的请求头这里要设置合理

        conn.connect();
        int responseCode = conn.getResponseCode();
        Object content = conn.getContent();



        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(conn.getInputStream(),"utf-8"));
        String inputLine;
        StringBuffer sb = new StringBuffer();
        while ((inputLine = bufferedReader.readLine()) != null) {
            sb.append(inputLine);
        }
        System.out.println("Response: " + sb.toString());
        JsonParser jsonParser = new JsonParser();
        JsonArray subInfos = jsonParser.parse(sb.toString()).getAsJsonObject()
                .getAsJsonObject("result")
                .getAsJsonArray("terms").get(0).getAsJsonObject()
                .get("chapter_info").getAsJsonArray().get(0).getAsJsonObject()
                .get("sub_info").getAsJsonArray();



        bufferedReader.close();

    }



}
