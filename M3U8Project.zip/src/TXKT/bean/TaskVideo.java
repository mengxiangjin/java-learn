package TXKT.bean;

import java.io.Serializable;

public class TaskVideo implements Serializable {
    private String vid;
    private int setVid;
    private int timeLen;
    private String coverUrl;
    private String name;
    private int state;
    private int aid;

    public String getVid() {
        return vid;
    }

    public void setVid(String vid) {
        this.vid = vid;
    }

    public int getSetVid() {
        return setVid;
    }

    public void setSetVid(int setVid) {
        this.setVid = setVid;
    }

    public int getTimeLen() {
        return timeLen;
    }

    public void setTimeLen(int timeLen) {
        this.timeLen = timeLen;
    }

    public String getCoverUrl() {
        return coverUrl;
    }

    public void setCoverUrl(String coverUrl) {
        this.coverUrl = coverUrl;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getState() {
        return state;
    }

    public void setState(int state) {
        this.state = state;
    }

    public int getAid() {
        return aid;
    }

    public void setAid(int aid) {
        this.aid = aid;
    }
}
