package TXKT.bean;

import java.io.Serializable;

public class TaskResidextInfo implements Serializable {
    private String times;
    private int txcloud;
    private String vid;

    public String getTimes() {
        return times;
    }

    public void setTimes(String times) {
        this.times = times;
    }

    public int getTxcloud() {
        return txcloud;
    }

    public void setTxcloud(int txcloud) {
        this.txcloud = txcloud;
    }

    public String getVid() {
        return vid;
    }

    public void setVid(String vid) {
        this.vid = vid;
    }
}
