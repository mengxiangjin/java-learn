package TXKT.bean;

import java.io.Serializable;

public class TaskInfo implements Serializable {

    private String restrictFlag;
    private String createTime;
    private String csid;
    private String introduce;
    private String timelen;
    private String specialFlag;
    private String endtime;
    private TaskResidextInfo residExt;
    private String termId;
    private TaskVideo video;
    private int type;
    private int bgtime;
    private int exprFlag;
    private int[] teList;
    private String name;
    private int taskBitFlag;
    private String residList;
    private int[] tuList;

}
