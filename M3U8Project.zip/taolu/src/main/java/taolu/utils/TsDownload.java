package taolu.utils;


import taolu.TaoLuMain;
import taolu.bean.PlayBackItem;

import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

import static taolu.TaoLuMain.DOWNLOAD_PATH;

/**
 * Ts 多线程下载类。
 */
public class TsDownload implements Runnable {


    private String downloadUrl;
    private int serialNumber;
    private String filename;
    private PlayBackItem playBackItem;
    private static int tsFileTotalCounts = 0;

    public TsDownload() {

    }

    public TsDownload(int serialNumber, String downloadUrl, PlayBackItem playBackItem) {
        this.downloadUrl = downloadUrl;
        this.serialNumber = serialNumber;
        this.filename = serialNumber + ".ts";
        this.playBackItem = playBackItem;
        tsFileTotalCounts++;
    }

    @Override
    public void run() {
        URL url = null;
        try {
            url = new URL(this.downloadUrl);
            System.out.println(Thread.currentThread().getName() + " 正在下载 " + this.filename + " 总片段 " +  playBackItem.getTsFileTotalCounts() + " ---" + playBackItem.getVideoTitle());
            URLConnection conn = url.openConnection();
            RandomAccessFile file = new RandomAccessFile(getDownloadTsPath(playBackItem) + this.filename, "rw");
            InputStream inputStream = conn.getInputStream();

            byte[] buffer = new byte[1024];
            int hasRead = 0;
            while ((hasRead = inputStream.read(buffer)) != -1) {
                file.write(buffer, 0, hasRead);
            }
//            if (playBackItem.getTsFileTotalCounts() == serialNumber) {
//                TaoLuMain.taskCounts = TaoLuMain.taskCounts - 1;
//            }
            TaoLuMain.taskCounts = TaoLuMain.taskCounts - 1;
            file.close();
            inputStream.close();
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public String getDownloadTsPath(PlayBackItem playBackItem) {
        return DOWNLOAD_PATH + "\\" + playBackItem.getNickName() + "\\" + playBackItem.getVideoTitle() + "\\";
    }
}
