package taolu.utils

object ConstantPool {

    const val anchorUserId = 370706
    const val taluPlayBackUrl = "http://live.taolu.black/live/live/video/anchor/"
    const val taluPlayBackUrlSize = 10
}