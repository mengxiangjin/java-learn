package taolu;

import com.google.gson.Gson;
import okhttp3.*;
import taolu.bean.PlayBackItem;
import taolu.bean.RespPlayBack;
import taolu.bean.TSBean;
import taolu.utils.TsDownload;

import java.io.*;
import java.net.URL;
import java.net.URLConnection;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class TaoLuMain {

    public static final String DOWNLOAD_PATH = "E:\\work\\taolu\\";

    public volatile static int taskCounts = 0;

    public static String anchorUserId = "370706";


    public static OkHttpClient okHttpClient;

    public static RespPlayBack currentRespPlayBack;
    public static int currentPages = 1;

    public static void main(String[] args) {
        okHttpClient = new OkHttpClient();
        startGetM3U8Resource();
    }

    public static void startGetM3U8Resource() {
        String url = "http://live.taolu.black/live/live/video/anchor/" + currentPages + "/10?anchorUserId=" + anchorUserId + "&sign=1745578191-c17548280b8d489fa64da236eff4d53c-0-e6558ed709eee7b8e0976c5edef652db&uid=218904&systemModel=Pixel 2 XL&appType=1&appVer=3.7.6&phoneBrand=google&version=3.7.6&deviceId=63bd2e866c6ef324&systemVersion=11&versionCode=20250105";
        Request request = new Request.Builder()
                .url(url)
                .addHeader("token","aiya_ede25263-98c2-4e96-85ad-f90e04401fc8d1")
                .addHeader("appVersion","{\"uid\":\"218904\",\"systemModel\":\"Pixel 2 XL\",\"appType\":\"1\",\"appVer\":\"3.7.6\",\"phoneBrand\":\"google\",\"version\":\"3.7.6\",\"deviceId\":\"63bd2e866c6ef324\",\"systemVersion\":\"11\",\"versionCode\":\"20250105\"}")
                .build();
        try {
            Response response = okHttpClient.newCall(request).execute();
            String responseBodyStr = response.body().string();
            Gson gson = new Gson();
            currentRespPlayBack = gson.fromJson(responseBodyStr, RespPlayBack.class);
            if (currentRespPlayBack.isSuccess()) {
                startDownloadM3U8();
                if (currentRespPlayBack.getData().getTotal() > currentPages * currentRespPlayBack.getData().getSize()) {
                    currentPages++;
                    startGetM3U8Resource();
                }
            }

        }catch (Exception e) {
            System.out.println(e.toString());
        }


    }


    public static void startDownloadM3U8() {
        long startTime = System.currentTimeMillis();
//        taskCounts = currentRespPlayBack.getData().getRecords().size();
        createParentDirs(currentRespPlayBack.getData().getRecords());
//        ExecutorService executorService = Executors.newFixedThreadPool(40);

        ExecutorService ffmpegExecutorService = Executors.newFixedThreadPool(40);

        // 下载外层m3u8 url
        for (int i = 0; i < currentRespPlayBack.getData().getRecords().size(); i++) {


            PlayBackItem playBackItem = currentRespPlayBack.getData().getRecords().get(i);

            //判断是否已经下载过
            String downloadFileName = playBackItem.getVideoTitle();
            String downloadParentDir = getDownloadParentDir(playBackItem);
            File file = new File(downloadParentDir);
            boolean hasDownload = false;
            if (file.isDirectory()) {
                File[] files = file.listFiles();
                for (int j = 0; j < files.length; j++) {
                    if (getFileNameWithoutExtension(files[j]).equals(downloadFileName) && files[j].isFile()) {
                        hasDownload = true;
                        break;
                    }
                }
            }

            if (playBackItem.getId() == 141605 || playBackItem.getId() == 143754 || playBackItem.getId() == 103746) {
                hasDownload = false;
            } else {
                hasDownload = true;
            }

            if (hasDownload) {
                System.out.println(downloadFileName + " 已下载过，跳过");
                //删除已创建的文件夹
                File tempFile = new File(getDownloadDir(playBackItem));
                try {
                    Files.walkFileTree(tempFile.toPath(), new SimpleFileVisitor<Path>() {
                        @Override
                        public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
                            Files.delete(file);
                            return FileVisitResult.CONTINUE;
                        }

                        @Override
                        public FileVisitResult postVisitDirectory(Path dir, IOException exc) throws IOException {
                            Files.delete(dir);
                            return FileVisitResult.CONTINUE;
                        }
                    });
                }catch (Exception e) {
                    System.out.println(e);
                }

                continue;
            } else {
                System.out.println(downloadFileName + " 未下载");
            }



            ExecutorService executorService = Executors.newFixedThreadPool(40);

            try {
                downloadFileFormTask(playBackItem);
                List<TSBean> tsBeanFromTask = getTsBeanFromTask(playBackItem);
                playBackItem.setTsFileTotalCounts(tsBeanFromTask.size());



                playBackItem.setTsBeanList(tsBeanFromTask);
                createMergeVideoTmpFromTask(playBackItem);

                taskCounts = playBackItem.getTsBeanList().size();
                for (int j = 0; j < playBackItem.getTsBeanList().size(); j++) {
                    TSBean tsBean = playBackItem.getTsBeanList().get(j);
                    executorService.execute(new TsDownload(tsBean.getSerialNumber(),tsBean.getDownloadURl(),playBackItem));
                };

                // 关闭线程池，等待任务结束。
                executorService.shutdown();
                while (!executorService.isTerminated() && taskCounts > 0) {
                    System.out.println("任务下载中");
                    try {
                        TimeUnit.SECONDS.sleep(1);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }

                ffmpegExecutorService.execute(() -> {
                    boolean isSuccess = mergeVideoFromTask(playBackItem);
                    System.out.println("result end: " + isSuccess);
                    if (isSuccess) {
                        // 移动目标mp4整合文件到上一级
                        try {
                            moveAndDelDirFromTask(playBackItem);
                        }catch (Exception e) {
                            System.out.println(e.toString());
                        }
                    }
                });
            } catch (Exception e) {
                System.out.println(e.toString());
            }


        }



        // 关闭线程池，等待任务结束。
        ffmpegExecutorService.shutdown();
        while (!ffmpegExecutorService.isTerminated()) {
            System.out.println("ffmpeg合并中");
            try {
                TimeUnit.SECONDS.sleep(1);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

//        // 关闭线程池，等待任务结束。
//        executorService.shutdown();
//        while (!executorService.isTerminated() && taskCounts > 0) {
//            System.out.println("任务下载中");
//            try {
//                TimeUnit.SECONDS.sleep(1);
//            } catch (InterruptedException e) {
//                e.printStackTrace();
//            }
//        }
//        // 任务下载完毕后
//        for (int i = 0; i < currentRespPlayBack.getData().getRecords().size(); i++) {
//            PlayBackItem playBackItem = currentRespPlayBack.getData().getRecords().get(i);
//            boolean isSuccess = mergeVideoFromTask(playBackItem);
//            System.out.println("result end: " + isSuccess);
//            if (isSuccess) {
//                // 移动目标mp4整合文件到上一级
//                moveAndDelDirFromTask(playBackItem);
//            }
//
//        }
        long second = (System.currentTimeMillis() - startTime) / 1000;
        long hour = second / 60 / 60;
        long minute = second / 60 % 60;
        long sec = second % 60 % 60;
        System.out.println("总耗时间: " + hour + "时" + minute + "分" + sec + "秒");
    }

    public static void createParentDirs (List<PlayBackItem> records) {
        for (int i = 0; i < records.size(); i++) {
            PlayBackItem playBackItem = records.get(i);
            //文件名+id号
            playBackItem.setVideoTitle(playBackItem.getVideoTitle() + "_" + playBackItem.getId());
            //去除空格
            playBackItem.setVideoTitle(playBackItem.getVideoTitle().replace(" ",""));
            String filePath = getDownloadDir(playBackItem);
            File itemFile = new File(filePath);
            itemFile.mkdirs();

        }
    }

    public static void downloadFileFormTask(PlayBackItem playBackItem) throws IOException {
        String m3u8Url = playBackItem.getVideoUrl();
        System.out.println("下载地址：" + m3u8Url);
        URL url = new URL(m3u8Url);
        URLConnection conn = url.openConnection();

        //m3u8下载的位置
        File f = new File(getM3u8FilePath(playBackItem));
        if (f.exists()) {
            f.delete();
        }

        RandomAccessFile file = new RandomAccessFile(getM3u8FilePath(playBackItem), "rw");
        InputStream inputStream = conn.getInputStream();

        byte[] buffer = new byte[1024];
        int hasRead = 0;
        while ((hasRead = inputStream.read(buffer)) != -1) {
            file.write(buffer, 0, hasRead);
        }
        file.close();
        inputStream.close();
    }

    public static List<TSBean> getTsBeanFromTask(PlayBackItem playBackItem) {
        int serialNumber = 0;
        String path = getM3u8FilePath(playBackItem);
        List<TSBean> tsBeanList = new ArrayList<>();

        System.out.println("读取文件地址：" + path);
        StringBuilder builder = new StringBuilder();
        try {
            RandomAccessFile randomAccessFile = new RandomAccessFile(path, "r");
            String content = null;
            while ((content = randomAccessFile.readLine()) != null) {
                if (!content.startsWith("#")) {
                    serialNumber++;
                    TSBean tsBean = new TSBean();
                    tsBean.setSerialNumber(serialNumber);
                    tsBean.setDownloadURl(getM3u8UrlPrefix(playBackItem) + content);
                    tsBeanList.add(tsBean);
                    builder.append(content + "\n");
                }
            }
            randomAccessFile.close();
            return tsBeanList;
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return tsBeanList;
    }


    public static void createMergeVideoTmpFromTask (PlayBackItem playBackItem) {
        List<TSBean> tsBeanList = playBackItem.getTsBeanList();
        File file = new File(getTsList(playBackItem));
        if (file.exists()) {
            file.delete();
        }
        try {
            RandomAccessFile randomAccessFile = new RandomAccessFile(getTsList(playBackItem), "rw");
            for (TSBean tsBean : tsBeanList) {
                randomAccessFile.write(("file '" + tsBean.getSerialNumber() + ".ts" + "'\n").getBytes());
            }
            randomAccessFile.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * 执行cmd命令时，容易卡死，下面这种方式 正好解决办法
     * https://blog.csdn.net/myloveheqiaozhi/article/details/51451285
     * @param filename 合并之后，视频的名字
     */
    public static boolean mergeVideoFromTask (PlayBackItem playBackItem) {
        System.out.println("开始合并视频...." + playBackItem.getVideoTitle());
        File file = new File(getTsList(playBackItem));
        String path = getDownloadTsPath(playBackItem).replaceAll("\\\\", "/");
        // 合并视频的命令
        try {
            Process process = Runtime.getRuntime().exec(String.format("ffmpeg.exe -f concat -safe 0 -i %s -c copy %s" +
                            ".mp4",
                    getTsList(playBackItem), path + playBackItem.getVideoTitle()));

            final InputStream is1 = process.getInputStream();
            new Thread(new Runnable(){
                @Override
                public void run() {
                    BufferedReader br = new BufferedReader(new InputStreamReader(is1));
                    try {
                        String outputLine = null;
                        while((outputLine=br.readLine())!= null) {
                            System.out.println(playBackItem.getVideoTitle() + "---->" + outputLine);
                        }

                    }catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }).start();
            InputStream is2 = process.getErrorStream();
            BufferedReader br2 = new BufferedReader(new InputStreamReader(is2));
            StringBuilder buf = new StringBuilder();
            String line = null;
            while((line = br2.readLine()) != null) {
                System.out.println(line);
                buf.append(line);
            };
            System.out.println("result:" + buf);
            while (br2.readLine() != null) {
                System.out.println(br2);
            }
            try {
                process.waitFor();
            }catch (InterruptedException e){
                e.printStackTrace();
                return false;
            }
            int i = process.exitValue();
            System.out.println( process.exitValue());

        } catch (IOException e) {
            e.printStackTrace();
            return false;
        } finally {
            file.delete();
        }
        return true;
    }

    public static void moveAndDelDirFromTask(PlayBackItem playBackItem)throws IOException {
        File dstFile = new File(getDownloadTsPath(playBackItem) + playBackItem.getVideoTitle() + ".mp4");
        if (!dstFile.exists()) return;
        File targetFile = new File(DOWNLOAD_PATH + "\\" + playBackItem.getNickName());
        Files.move(dstFile.toPath(),targetFile.toPath().resolve(dstFile.toPath().getFileName()), StandardCopyOption.REPLACE_EXISTING);
        File file = new File(DOWNLOAD_PATH + "\\" + playBackItem.getNickName() + "\\" + playBackItem.getVideoTitle() + "\\");
        if (!file.exists() || file.isFile()) return;
        Files.walkFileTree(Paths.get(file.getPath()), new FileVisitor<Path>() {
            @Override
            public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs) throws IOException {
                return FileVisitResult.CONTINUE;
            }

            @Override
            public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
                Files.delete(file);
                return FileVisitResult.CONTINUE;
            }

            @Override
            public FileVisitResult visitFileFailed(Path file, IOException exc) throws IOException {
                return FileVisitResult.CONTINUE;
            }

            @Override
            public FileVisitResult postVisitDirectory(Path dir, IOException exc) throws IOException {
                Files.delete(dir);
                return FileVisitResult.CONTINUE;
            }
        });
        file.delete();
    }


    public static String getM3u8FilePath(PlayBackItem playBackItem) {
        return DOWNLOAD_PATH + playBackItem.getNickName() + "\\" + playBackItem.getVideoTitle() +  "\\" +  "tmp.m3u8";
    }

    public static String getM3u8UrlPrefix(PlayBackItem playBackItem) {
        int targetIndex = playBackItem.getVideoUrl().lastIndexOf("/") + 1;
        return playBackItem.getVideoUrl().substring(0,targetIndex);
    }

    public static String getTsList(PlayBackItem playBackItem) {
        return DOWNLOAD_PATH + playBackItem.getNickName() + "\\" + playBackItem.getVideoTitle() +  "\\" +  "tsList.txt";
    }

    public static String getDownloadTsPath(PlayBackItem playBackItem) {
        return DOWNLOAD_PATH + playBackItem.getNickName() + "\\" + playBackItem.getVideoTitle() +  "\\";
    }

    public static String getDownloadDir(PlayBackItem playBackItem) {
        return DOWNLOAD_PATH + playBackItem.getNickName() + "\\" + playBackItem.getVideoTitle();
    }

    public static String getDownloadParentDir(PlayBackItem playBackItem) {
        return DOWNLOAD_PATH + playBackItem.getNickName() + "\\";
    }

    public static String getFileNameWithoutExtension(File file) {
        String name = file.getName();
        int dotIndex = name.lastIndexOf(".");
        if (dotIndex > 0) {
            return name.substring(0,dotIndex);
        }
        return name;
    }
}
